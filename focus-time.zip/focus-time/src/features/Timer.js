import React, { useState } from 'react';
import { View, Text, StyleSheet, Vibration, Platform } from 'react-native';
import { Countdown } from '../components/Countdown';
import { RoundedButton } from '../components/RoundedButton';
import { ProgressBar } from 'react-native-paper';
import {Timing} from './Timing'
import {useKeepAwake} from 'expo-keep-awake';

const DEFAULT_TIME = 0.5;
export const Timer = ({ focusSubject, onTimerEnd, clearSubject }) => {
  useKeepAwake();
  const [minutes, setMinutes] = useState(DEFAULT_TIME);
  const [isStarted, setIsStarted] = useState(false);
  const [progress, setProgress] = useState(1);

  const onProgress = (progress) => {
    setProgress(progress)
  };

  const vibrate= () => {
    if(Platform.OS === 'ios') {
      const interval = setInterval(() => Vibration.vibrate(), 1000);
      setTimeout(() => clearInterval(interval), 1000);
    } else {
      Vibration.vibrate(1000);
    }
  };

  const changeTime = (min) => {
    setMinutes(min);
    setProgress(1);
    setIsStarted(false);
  };

  const onEnd=()=>{
    vibrate();
    setMinutes(DEFAULT_TIME);
    setProgress(1);
    setIsStarted(false);
    onTimerEnd();
  };

  return (
    <View style={styles.container}>
    <View style={{alignSelf: 'flex-end', paddingRight: 20}}>
      <RoundedButton title="X" size={25} onPress={clearSubject}/>
    </View>
      <Countdown minutes={minutes} isPaused={!isStarted} onProgress={onProgress} onEnd={onEnd}/>
      <View style={{
        width: '100%', height: 10, backgroundColor: 'steelblue', paddingBot: 5, marginTop: 5
      }}>
      <ProgressBar color='yellow' progress={progress} style={{height:10}}/>
      </View>
      <View style={styles.timingStl}>
        <Timing onChangeTime={changeTime}/>
      </View>
      <Text style={styles.text}>Focusing on:</Text>
      <Text style={styles.task}>{focusSubject}</Text>
      {isStarted ? (
        <RoundedButton
          title="||"
          size={50}
          onPress={() => setIsStarted(false)}
        />
      ) : (
        <RoundedButton title=">" size={50} onPress={() => setIsStarted(true)} />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 20,
    alignItems: 'center',
  },
  text: {
    color: 'grey',
  },
  task: {
    color: 'white',
    fontWeight: 'bold',
  },
  timingStl:{
    flex: 0.3,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 15

  }
});
