import React from 'react';
import {useState} from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { TextInput } from 'react-native-paper';
import { RoundedButton } from '../components/RoundedButton';

export const Focus = ({addSubject}) => {
  const [tmpItem, setTmpState] = useState(null)
  return (
    <View style={styles.container}>
      <View style={styles.titleContainer}>
        <Text style={styles.title}>
          What subject would you like to focus on ?
        </Text>
      </View>
      <View style={styles.inputContainer}>
        <TextInput style={{ flex: 1, marginRight: 5 }}
        onSubmitEditing={({nativeEvent}) =>
        {setTmpState(nativeEvent.text)}
        }/>
        <RoundedButton size={50} title="+" onPress={() =>
        {addSubject(tmpItem)}}/>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 5
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center'
  },
  title: {
    color: 'grey',
    fontWeight: 'bold',
    fontSize: 15,
  },
  titleContainer: {
    paddingTop: 30,
    justifyContent: 'center',
  },
});
