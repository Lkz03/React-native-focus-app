import React from 'react';
import {useState, useEffect} from 'react';
import {Text, View, StyleSheet} from 'react-native'

const minutesToMiliSecs = (min) => min*1000*60;
const formatTime = (time) => time < 10 ? `0${time}` : time;

export const Countdown = ({
  minutes = 20,
  isPaused,
  onProgress,
  onEnd
}) => {
  const interval = React.useRef(null);
  const [miliSecs, setMiliSecs] = useState(null)

  const countDown = () => {
    setMiliSecs((time) => {
      if(time === 0) {
        clearInterval(interval.current);
        onEnd();
        return time;
      } else {
        const timeleft = time - 1000;
        onProgress(timeleft / minutesToMiliSecs(minutes));
        return timeleft;
      }
    })
  }

  useEffect(() =>{
    setMiliSecs(minutesToMiliSecs(minutes));
  }, [minutes])

  useEffect(() => {
    if(!isPaused)
    interval.current = setInterval(countDown, 1000);
    return () => clearInterval(interval.current)
  }, [isPaused])

  const minute = Math.floor(miliSecs /1000 / 60) % 60;
  const seconds = Math.floor(miliSecs /1000) % 60;
  return(
    <View>
      <Text style={styles.text}>{formatTime(minute)}:{formatTime(seconds)}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  text: {
    padding: 10,
    backgroundColor: 'rgba(255, 255, 255, 0.2)'
  }
})